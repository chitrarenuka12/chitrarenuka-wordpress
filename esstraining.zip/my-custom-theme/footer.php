<footer>
    <p>&copy; <?php echo date("Y"); ?> Intern Training</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>