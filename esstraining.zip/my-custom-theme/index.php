<?php get_header(); ?>

<main>
  <h1>Welcome to the ESS, this is a Training WordPress Theme 🎉</h1>
  <p>This theme is working. Start editing it in <code>wp-content/themes/my-custom-theme/</code> or Try to create your own basic theme</p>
</main>

<?php get_footer(); ?>